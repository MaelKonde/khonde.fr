<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Histoire de vie orientée sur l’Éducation | Témoignage de résilience</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Dublin Core Metadata -->
    <meta name="DC.Title" content="Histoire de vie orientée sur l’Éducation">
    <meta name="DC.Creator" content="Maël Khonde">
    <meta name="DC.Subject" content="Éducation, Résilience, Échec académique, Informatique, Témoignage personnel, Kinshasa">
    <meta name="DC.Description" content="Ce récit retrace le parcours de Maël, depuis son échec à l’examen de médecine jusqu'à son épanouissement en informatique. Un témoignage de résilience face à l’adversité.">
    <meta name="DC.Publisher" content="Maël Khonde">
    <meta name="DC.Date" content="2025-05-09">
    <meta name="DC.Language" content="fr">
    <meta name="DC.Identifier" content="https://www.khonde.fr/histoire-de-vie-education">
    <meta name="DC.Format" content="text/html">
    <link href="style.css" style="text/css" rel="stylesheet"
</head>
<body>
    <!-- Menu de navigation -->
    <nav class="menu">
        <ul>
         
            <li><a href="#section-1">Résilience</a></li>
            <li><a href="#section-2">Souvenirs</a></li>
            <li><a href="https://www.khonde.fr/histoire-de-vie-education/">khonde.fr sans CSS</a></li>
            
        </ul>
        <div class="clear"></div>
    </nav>

    <div class="container">
        <h1>Sommaire</h1>
        <h3><a href="#section-1">Les tournants de la vie et la résilience face à l'échec académique</a></h3>
        <h3><a href="#section-2">Les souvenirs d'enfance et la construction des passions</a></h3>

        <h2 id="section-1">Les tournants de la vie et la résilience face à l'échec académique</h2>
        <img src="map-of-dr-congo.jpg" alt="Carte du Congo" class="img-float">
        <p>
            <span class="lettering">C</span>'était un après-midi chaud à Kinshasa, et j'étais assis nerveusement dans une
            grande salle remplie d'autres élèves. La salle était silencieuse, à l'exception du
            bruissement occasionnel du papier et du cliquetis des stylos sur les tables. C'était
            l'examen d'entrée en médecine, le moment décisif pour lequel j'avais travaillé pendant
            des années. Je pouvais littéralement sentir la tension dans l'air.
        </p>
        <p>
            Le rêve de devenir <span class="highlight">pédiatre</span> m'avait animé tout au long de ma scolarité. J'étais
            déterminé à réaliser ce rêve. Mais plus tard, lorsque j'ai eu les résultats entre les mains,
            mon monde s'est écroulé pendant un moment : <span class="highlight">J'avais échoué à l'examen.</span>
        </p>
        <p>
            Ce moment, qui a d'abord semblé être une défaite amère, est devenu un tournant
            dans ma vie. Il m'a obligé à reconsidérer mes projets et à prendre un nouveau chemin.
            Cependant, dans l'obscurité de cette déception, une nouvelle idée a germé – la possibilité
            de faire mes preuves dans un tout autre domaine : <span class="highlight">l'informatique</span>. Ce qui ressemblait au
            départ à un simple plan B s'est transformé en l'une des meilleures décisions de ma vie et
            m'a ouvert un monde plein de nouvelles opportunités et de nouveaux défis.
        </p>
        <div class="clear"></div>

        <p>
            Je suis né à Kinshasa, la capitale de la République démocratique du Congo, une
            ville vibrante de diversité culturelle et d'énergie. Mes parents accordaient une grande
            importance à l'éducation, qu'ils considéraient comme la clé d'une vie meilleure et d'une
            croissance personnelle. Dès mon plus jeune âge, on m'a inculqué des valeurs telles que
            la discipline, le respect et l'importance de l'éducation. Mon souhait de carrière initial était
            de devenir pédiatre, inspiré par la conviction profonde de vouloir aider les autres.
        </p>
        <p>
            Après l'annonce des résultats, un profond sentiment de tristesse s'est abattu sur
            moi. J'avais investi tant de temps, d'efforts et de rêves dans cet examen, et échouer
            semblait effacer tout cela en un instant. Chaque fois que je repensais à cet après-midi
            chaud à Kinshasa, à cette salle silencieuse où j'avais donné le meilleur de moi-même, un
            sentiment d'impuissance et de déception me submergeait. C'était comme si tout ce que
            j'avais imaginé pour mon avenir venait de s'effondrer.
        </p>
        <p>
            Cependant, au milieu de cette obscurité, mes parents sont devenus ma lumière.
            Plutôt que de me réprimander ou de partager ma tristesse, ils m'ont entouré de leur
            amour et de leurs encouragements. Ils ont toujours cru que l'éducation était une voie vers
            de nouvelles opportunités, mais ils m'ont aussi appris que les échecs font partie du
            chemin vers le succès. Leur soutien inébranlable m'a aidé à voir au-delà de l'échec
            immédiat.
        </p>
        <p>
            Ma mère, avec sa sagesse habituelle, m'a rappelé que la vie ne suit pas toujours le
            plan que nous avons tracé. Elle m'a encouragé à explorer de nouvelles voies et à trouver
            d'autres moyens de réaliser mes aspirations. Mon père, quant à lui, m'a rappelé que la
            vraie force réside dans la capacité à se relever après une chute. Ensemble, ils ont ravivé
            en moi une étincelle d'espoir.
        </p>

        <h2 id="section-2">Les souvenirs d'enfance et la construction des passions</h2>
        <img src="medicine-18984.jpg" alt="Éléments médicaux" class="img-float-left">
        <p>
            <span class="lettering">M</span>es années d'école primaire dans une école francophone de Kinshasa ont été
            riches en expériences marquantes. Les enseignants ont éveillé mon enthousiasme pour
            l'apprentissage, en particulier dans le domaine des sciences. Monsieur Monga, mon
            professeur de mathématiques, en particulier, m'a inspiré à penser de manière critique et
            à résoudre des problèmes. Ces premières années ont jeté les bases de mon amour pour
            la science et de mon rêve initial de travailler dans le domaine médical.
        </p>
        <div class="clear"></div>
        <p>
            Mes années d'école primaire restent gravées dans ma mémoire comme une
            période d'intense camaraderie et de détermination à réussir. Je faisais toujours partie des
            élèves ayant les meilleures notes, ce qui me poussait à donner le meilleur de moi-même.
            Entourés de collègues tout aussi travailleurs, nous formions une petite communauté
            d'apprenants dévoués, partageant nos aspirations et nos rêves pour l'avenir.
        </p>
        <p>
            Nous avons passé d'innombrables heures ensemble, non seulement en classe,
            mais aussi à l'extérieur, à étudier, à débattre de divers sujets et à nous motiver. Si je me
            concentrais souvent sur mes études, j'étais aussi connu pour être un peu provocateur,
            animant les discussions et apportant une touche d'humour à nos moments sérieux. Ce
            rôle d'hôte m'a permis de tisser des liens encore plus forts avec mes camarades de
            classe.
        </p>
        <img src="dawn-sunset-people.jpg" alt="Souvenirs d'enfance" class="img-float">
        <p>
            Ces collègues d'enfance sont rapidement devenus plus que des amis. Ils sont
            devenus une famille, un soutien constant dans les moments de doute et de fête. Ce qui
            rend ces liens encore plus remarquables, c'est que nous avons tous poursuivi nos études
            supérieures avec la même détermination qui nous animait dans notre jeunesse. Chacun
            d'entre nous a réussi à atteindre ses objectifs académiques, transformant ses rêves
            d'enfant en réalités tangibles.
        </p>
        <div class="clear"></div>
        <p>
            Aujourd'hui encore, nous restons en contact, partageant nos succès, nos défis et
            nos souvenirs d'une époque où nous étions simplement des enfants avec de grands
            rêves. Ces souvenirs sont un rappel précieux de l'importance des amitiés d'enfance et de
            la manière dont elles peuvent façonner notre vie pour toujours.
        </p>
    </div>

    <footer>
        <h4>Pour me contacter :</h4>
        <p>E-mail : <a href="mailto:maelkhonde@web.de">maelkhonde@web.de</a></p>
        <p>LinkedIn : <a href="https://www.linkedin.com/in/ma%C3%ABl-khonde/">Maël Khonde</a></p>
        <p>&copy; 2025 Maël Khonde</p>
    </footer>
</body>
</html>
