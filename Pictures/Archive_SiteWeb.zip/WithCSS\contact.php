<?php
$host = '193.203.168.212';
$db = 'u443962091_tp_OUR';
$user = 'u443962091_mael';
$pass = 'Watch@tower1!@€@@€@';
$charset = 'utf8mb4';


$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}


$errors = [];
$success = false;

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sécurisation et validation des champs
    $nom = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    $adresse = trim($_POST['adresse'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (strlen($nom) < 2) $errors[] = "Nom trop court.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Email invalide.";
    if (!preg_match('/^[0-9\+\-\s]{6,}$/', $telephone)) $errors[] = "Téléphone invalide.";
    if (strlen($adresse) < 5) $errors[] = "Adresse trop courte.";
    if (strlen($message) < 10) $errors[] = "Message trop court.";

    if (empty($errors)) {
        // Insertion en base
        $stmt = $pdo->prepare("INSERT INTO messages (nom, email, telephone, adresse, message, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$nom, $email, $telephone, $adresse, $message]);

        // Envoi du mail
        $to = 'maelkhonde@web.de';
        $subject = "Nouveau message depuis le formulaire de contact";
        $body = "Nom : $nom\n";
        $body .= "Email : $email\n";
        $body .= "Téléphone : $telephone\n";
        $body .= "Adresse : $adresse\n\n";
        $body .= "Message :\n$message\n";
        $headers = "From: $email\r\n";
        $headers .= "Reply-To: $email\r\n";
        $headers .= "Content-Type: text/plain; charset=utf-8\r\n";

        mail($to, $subject, $body, $headers);

        $success = true;
        $_POST = [];
    }
}

// Lecture des derniers messages
$stmt = $pdo->query("SELECT * FROM messages ORDER BY created_at DESC LIMIT 10");
$messages = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Contact / Mael Khonde</title>
    <link rel="icon" type="image/png" href="">
    <link rel="shortcut icon" href="img1.png" type="image/x-icon">
    <style>
        body { font-family: Arial, sans-serif; margin: 2rem; }
        .form-row { display: flex; gap: 1rem; margin-bottom: 1rem; }
        input, textarea { width: 100%; padding: 0.5rem; }
        textarea { resize: vertical; }
        .error { color: red; }
        .success { color: green; }
        .messages { margin-top: 2rem; }
        .message { border-bottom: 1px solid #ddd; padding: 0.7rem 0; }
        .message strong { color: #2db886; }
        @media (max-width: 600px) {
            .form-row { flex-direction: column; }
        }
    </style>
</head>
<body <?php if ($success): ?>style="background: url('image.png') center center/cover no-repeat fixed;"<?php endif; ?>>
    <h1>Contact / Mael Khonde</h1>
    <?php if ($success): ?>
        <div class="success" style="margin-bottom:2rem;">
            <p>Merci de nous avoir contacté.<br>Votre message a bien été enregistré et envoyé !</p>
            <a href="index.php" style="
                display:inline-block;
                margin-top:1rem;
                padding:0.7rem 1.5rem;
                background:#2db886;
                color:#fff;
                border-radius:0.5rem;
                text-decoration:none;
                font-weight:bold;
                font-size:1.1rem;
                box-shadow:0 2px 8px rgba(0,0,0,0.07);
                transition:background 0.2s;
            " onmouseover="this.style.background='#249d6d'" onmouseout="this.style.background='#2db886'">
                Retour à l'accueil
            </a>
        </div>
    <?php elseif ($errors): ?>
        <ul class="error">
            <?php foreach ($errors as $err) echo "<li>$err</li>"; ?>
        </ul>
    <?php endif; ?>


    <?php if (!$success): ?>
    <form method="POST" action="">
        <div class="form-row">
            <input type="text" name="nom" placeholder="Votre nom" required value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>" />
            <input type="email" name="email" placeholder="Votre email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" />
        </div>
        <div class="form-row">
            <input type="text" name="telephone" placeholder="Votre Téléphone" required value="<?= htmlspecialchars($_POST['telephone'] ?? '') ?>" />
            <input type="text" name="adresse" placeholder="Adresse Postale & ville" required value="<?= htmlspecialchars($_POST['adresse'] ?? '') ?>" />
        </div>
        <textarea rows="4" name="message" placeholder="Votre message" required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
        <button type="submit">Envoyer</button>
    </form>
    <?php endif; ?>

    
</body>

</html>
