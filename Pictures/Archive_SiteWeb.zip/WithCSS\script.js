document.addEventListener('DOMContentLoaded', function() {

    // 1. AFFICHER / MASQUER LA SECTION "Souvenirs"
    const btnToggle = document.createElement('button');
    btnToggle.textContent = "Afficher/Masquer les souvenirs d'enfance";
    btnToggle.style.margin = '20px 0';
    const section2 = document.getElementById('section-2');
    if (section2) {
        section2.parentNode.insertBefore(btnToggle, section2);
        btnToggle.addEventListener('click', function() {
            section2.style.display = (section2.style.display === 'none') ? '' : 'none';
        });
    }

    // 2. ZOOM SUR LES IMAGES
    const images = document.querySelectorAll('img');
    images.forEach(function(img) {
        img.style.transition = 'transform 0.3s ease';
        img.addEventListener('mouseover', function() {
            img.style.transform = 'scale(1.1)';
        });
        img.addEventListener('mouseout', function() {
            img.style.transform = 'scale(1)';
        });
    });

    // 3. CONFIRMATION AVANT DE QUITTER LE SITE EN CLIQUANT SUR "khonde.fr sans CSS"
    // Ciblage précis du lien par son href
    const khondeLink = document.querySelector('nav a[href="https://www.khonde.fr/histoire-de-vie-education/"]');
    if (khondeLink) {
        khondeLink.addEventListener('click', function(e) {
            const confirmation = confirm("Voulez-vous vraiment quitter la version stylisée de ce site ?");
            if (!confirmation) {
                e.preventDefault();
            }
        });
    }

    // 4. MISE EN ÉVIDENCE DES MOTS IMPORTANTS AU SURVOL
    const highlights = document.querySelectorAll('.highlight');
    highlights.forEach(function(el) {
        el.style.transition = 'background-color 0.4s, color 0.4s';
        el.addEventListener('mouseover', function() {
            el.style.backgroundColor = '#ffd54f';
            el.style.color = '#000';
        });
        el.addEventListener('mouseout', function() {
            el.style.backgroundColor = '';
            el.style.color = '';
        });
    });

    // 5. ANIMATION DES LETTRINES
    const letterings = document.querySelectorAll('.lettering');
    letterings.forEach(function(span) {
        span.style.transition = 'color 0.5s ease';
        span.addEventListener('mouseenter', function() {
            span.style.color = '#e91e63';
        });
        span.addEventListener('mouseleave', function() {
            span.style.color = '';
        });
    });

});